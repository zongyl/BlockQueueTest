rm -rf *.o
make -f Makefile.One
make -f Makefile.Two
