#include<queue>
#include<pthread.h>

template<typename T>
class BlockingQueue {
public:
    BlockingQueue () {
        pthread_mutex_init(&mMutex, NULL);
        pthread_cond_init(&mCond,NULL);
    }
    ~BlockingQueue() {}

    void push(const T &input) {
        pthread_mutex_lock(&mMutex);
        mQueue.push(input);
        pthread_mutex_unlock(&mMutex);
        pthread_cond_signal(&mCond);
    }

    T pop() {
        pthread_mutex_lock(&mMutex);
        while(mQueue.empty()) {
            pthread_cond_wait(&mCond, &mMutex);
        }
        T front = mQueue.front();
        mQueue.pop();
        pthread_mutex_unlock(&mMutex);
        return front;
    }

    size_t size() {
        pthread_mutex_lock(&mMutex);
        int num = mQueue.size();
        pthread_mutex_unlock(&mMutex);
        return num;
    }

private:
    pthread_mutex_t mMutex ;
    pthread_cond_t mCond;
    std::queue<T> mQueue;
};

