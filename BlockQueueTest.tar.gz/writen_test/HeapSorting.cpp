#include"HeapSorting.h"

void HeapSorting::InitMaxHeap(string &arry)
{
	mLen = arry.length();
	for (int i = mLen/2 - 1; i >= 0; i--) 
	{
		AdjustHeap(arry, i);
	}

}
void HeapSorting::AdjustHeap(string &arry,int i )
{
	 int left = 2 * i + 1;
     int right = 2 * i + 2;
     int largest = i;
 
    if (left < mLen && arry[left] > arry[largest]) {
        largest = left;
    }
 
    if (right < mLen && arry[right] > arry[largest]) {
        largest = right;
    }
 
    if (largest != i) {
        Swap(arry, i, largest);
        AdjustHeap(arry, largest);
    }
}
void HeapSorting::Swap(string &arry,int i ,int j)
{
	
	char temp = arry[i];
   arry[i] = arry[j];
   arry[j] = temp;
}

string&HeapSorting::HeapSort(string &arry)
{
	InitMaxHeap(arry);
	 
	for (int i = arry.length()-1; i > 0; i--)
	{
			Swap(arry, 0, i);
			mLen--;
			AdjustHeap(arry, 0);
	}
	return arry;
}


