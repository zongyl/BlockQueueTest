#include <string>
using  std::string;
class HeapSorting
{
	public:
		HeapSorting(){}
		~HeapSorting(){}
		public:
		string& HeapSort(string &arry);
		private:		
		void InitMaxHeap(string &arry);
		void AdjustHeap(string &arry,int i );
		void Swap(string &arry,int i ,int j);	
		private:
			long unsigned int mLen;
};
