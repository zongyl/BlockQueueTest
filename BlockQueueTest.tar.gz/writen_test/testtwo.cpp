#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "HeapSorting.h"
#include <iostream>
#include <pthread.h>
#include <ev.h>


using namespace std;

unsigned long gCountNum=0;

pthread_t threadOne;

void createstr(string &str,int len)
{
	int randnum;
	char strlist[63]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	for(int i =0;i<len;i++)
	{
		randnum = rand()%62;
		str.append(1,strlist[randnum]);
	}
}

void* cbOne(void *)
{
	while(1)
	{
	string str;
	createstr(str,12);
	cout<<str<<endl;
	HeapSorting heap;
	heap.HeapSort(str);
	cout<<str<<endl;
	printf("gCountNum is :%ld\n",gCountNum++);
	
	}	
}

static void timeout_cb(EV_P_ ev_timer *w,int revnts)
{
	pthread_cancel(threadOne);
	puts("time out");
	ev_break(EV_A_ EVBREAK_ONE);
}

int main()
{
	struct ev_loop *loop = EV_DEFAULT;
	ev_timer timeout_watcher;
	ev_timer_init(&timeout_watcher,timeout_cb,10,0);
	ev_timer_start(loop,&timeout_watcher);	

	int ret = pthread_create(&threadOne,NULL,cbOne,NULL);
	if(ret)
	{
		printf("create one error\n");
		exit(0);
	}

	ev_run(loop,0);
	pthread_join(threadOne,NULL);

	return 0;
}
